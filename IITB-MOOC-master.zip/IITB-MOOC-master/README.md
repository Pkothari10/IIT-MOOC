# IITB-MOOC-

Massive Online Open Courses are online courses that are aimed at large scale interactive participation and open access via the web. 
The objective was to gauge the ability to work with real MOOC data and learning analytics. 
Analysis of the MOOC forum course of IIT Bombay was performed using methods like Data Cleaning, Data Extraction, and Visualization. 
The methods used for the extraction of data were manually coded which were then used for the visual analysis. 
This was the preliminary analysis before developing a 'Software Tool to measure the effect of teacher presence in the discussion forums of MOOCs on Peer Learning'.
